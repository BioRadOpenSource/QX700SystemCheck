{
  "alg": "Ed25519",
  "key_id": "4a2a8dfd33693172",
  "signature": "hmhMFh+05mN8SYiLvkM2NwMeNPVhKMqgR6b5QZAbZcaBIgG+3RHeiF4DRBDHXs0W7HwUIGZIw1o1I8xXeAkqDQ=="
}