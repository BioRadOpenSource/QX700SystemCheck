{
  "alg": "Ed25519",
  "key_id": "4a2a8dfd33693172",
  "signature": "rZFHBDD+ipeEhalM9hFFCqvf8q+y73kTOrXd9hPhGGCGOEQDSN5r9DNp8R4A2fVnVSU5cFSzfnjcwIcV4r5wDw=="
}