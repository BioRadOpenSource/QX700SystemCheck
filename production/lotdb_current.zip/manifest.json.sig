{
  "alg": "Ed25519",
  "key_id": "d6aeb968998d200e",
  "signature": "7S/TrmmYsh5ygUNc7hcYui1ekgb6bqBwm0HQf+Qu7+VGKH5Iq4VdMjbwwbiCWzGnzAJ7s1kARDtaIrpywZp6AQ=="
}